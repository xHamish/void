---
title: A new Gatsby starter for Tina
date: '2019-09-18T03:00:00.000Z'
heading_color: pink
description: 'My new post. '
blocks:
  - _template: heading
    text: My first Tina post
  - _template: image
    alt: My kitchen
    src: >-
      https://images.unsplash.com/photo-1556910096-6f5e72db6803?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2250&q=80
gallery:
  - alt: Another photo
    src: >-
      https://images.unsplash.com/photo-1556910096-6f5e72db6803?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2250&q=80
    photographer:
      name: ''
      social:
        - {}
draft: true
---

# TootToot

[test]()

