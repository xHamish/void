---
title: My Second Post!
date: '2015-05-06T23:46:37.121Z'
description: Test
heading_color: '#404040'
draft: false
thumbnail: ../hello-world/salty_egg.jpg
---
Wow! I love _**blogging**_ so much already.

testa

```javascript
test a 
```

Did you know that `"despite its name`, salted _**duck**_ eggs can also be made from chicken eggs, though the **taste** and texture `will` be somewhat different, and the egg yolk will be less rich."?asdf a

> test

Yes ([Wikipedia Link](http://en.wikipedia.org/wiki/Salted_duck_egg)) asdf

##### Yeah, I didn't either.