# `@tinacms/form-builder`

A React component for building forms registered with `@tinacms/cms`.

## Installation

```
npm install --save @tinacms/form-builder
```

or

```
yarn add @tinacms/form-builder
```

## Getting Started

```javascript
import {} from '@tinacms/react-core'
```
