`foo`
`foo ` bar`
`foo`
`foo bar baz`