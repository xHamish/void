![]({{ site.baseurl }}/uploads/{{ something.else}}/image.png)
