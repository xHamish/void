\####### more than six is a paragraph

\#no trailing space is a paragraph

\#5 numbers too

\## not heading because the first is escaped

    # Four spaces is too much.