*foo`*`

[not a`link](/foo`)