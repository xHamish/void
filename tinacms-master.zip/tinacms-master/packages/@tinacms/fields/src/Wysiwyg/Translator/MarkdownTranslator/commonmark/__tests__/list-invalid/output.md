\-one

2\.two

1234567890\. not ok

\-1. don't be so negative