# Tina-fields

`Tina-fields` is a react component library providing some base styling for simple elements in the Tina package

# Getting Started

Components should be added to the `/src` directory. To add the field to the [Storybook](https://storybook.js.org/docs/basics/introduction/) documentation, add a `x.story.tsx` file to `/stories`.

## Usage

To view documentation on the fields, from inside the `/Tina-fields` directory, run `npm run storybook`
