# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.1.1-alpha.1](https://github.com/tinacms/tinacms/compare/@tinacms/teams@0.1.1-alpha.0...@tinacms/teams@0.1.1-alpha.1) (2019-12-06)

**Note:** Version bump only for package @tinacms/teams





## 0.1.1-alpha.0 (2019-12-06)


### Bug Fixes

* **teams:** move cookie dependencies to their proper package ([270888d](https://github.com/tinacms/tinacms/commit/270888d))
