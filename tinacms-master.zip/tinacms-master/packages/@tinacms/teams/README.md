# @tinacms/teams

Express middleware for authenticating and authorizing with [Tina Teams](https://tinacms.org/teams/).

## Install

```
npm install --save @tinacms/teams
```

or

```
yarn install @tinacms/teams
```

## How to Use

**TODO**
