# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.2.1-alpha.0](https://github.com/tinacms/tinacms/compare/@tinacms/react-core@0.2.0...@tinacms/react-core@0.2.1-alpha.0) (2019-12-06)

**Note:** Version bump only for package @tinacms/react-core





# [0.2.0](https://github.com/tinacms/tinacms/compare/@tinacms/react-core@0.2.0-alpha.0...@tinacms/react-core@0.2.0) (2019-12-02)

**Note:** Version bump only for package @tinacms/react-core





# [0.2.0-alpha.0](https://github.com/tinacms/tinacms/compare/@tinacms/react-core@0.1.1-alpha.0...@tinacms/react-core@0.2.0-alpha.0) (2019-11-28)


### Features

* **useGlobalForm:** add hook for registering global forms ([d450cae](https://github.com/tinacms/tinacms/commit/d450cae))





## 0.1.1-alpha.0 (2019-11-25)

**Note:** Version bump only for package @tinacms/react-core
