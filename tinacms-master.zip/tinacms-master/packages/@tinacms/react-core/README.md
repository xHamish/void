# @tinacms/react-core

_Note: This is an internal module for interacting with the `@tinacms/core`. It is meant for use within `tinacms`. You probably want to be using `react-tinacms`._

A React wrapper for `@tinacms/core`.
