# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.10-alpha.0](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.9...demo-cra@1.0.10-alpha.0) (2019-12-06)

**Note:** Version bump only for package demo-cra





## [1.0.9](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.9-alpha.2...demo-cra@1.0.9) (2019-12-02)

**Note:** Version bump only for package demo-cra





## [1.0.9-alpha.2](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.9-alpha.1...demo-cra@1.0.9-alpha.2) (2019-12-02)

**Note:** Version bump only for package demo-cra





## [1.0.9-alpha.1](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.9-alpha.0...demo-cra@1.0.9-alpha.1) (2019-11-28)

**Note:** Version bump only for package demo-cra





## [1.0.9-alpha.0](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.8...demo-cra@1.0.9-alpha.0) (2019-11-25)

**Note:** Version bump only for package demo-cra





## [1.0.8](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.8-alpha.1...demo-cra@1.0.8) (2019-11-25)

**Note:** Version bump only for package demo-cra





## [1.0.8-alpha.1](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.8-alpha.0...demo-cra@1.0.8-alpha.1) (2019-11-25)

**Note:** Version bump only for package demo-cra





## [1.0.8-alpha.0](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.7...demo-cra@1.0.8-alpha.0) (2019-11-25)

**Note:** Version bump only for package demo-cra





## [1.0.7](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.7-alpha.1...demo-cra@1.0.7) (2019-11-18)

**Note:** Version bump only for package demo-cra





## [1.0.7-alpha.1](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.6...demo-cra@1.0.7-alpha.1) (2019-11-18)

**Note:** Version bump only for package demo-cra





## [1.0.7-alpha.0](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.6...demo-cra@1.0.7-alpha.0) (2019-11-18)

**Note:** Version bump only for package demo-cra





## [1.0.6](https://github.com/tinacms/tinacms/compare/demo-cra@1.0.5...demo-cra@1.0.6) (2019-11-14)

**Note:** Version bump only for package demo-cra
