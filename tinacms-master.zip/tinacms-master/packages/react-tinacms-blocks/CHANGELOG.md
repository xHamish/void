# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.1.1-alpha.0](https://github.com/tinacms/tinacms/compare/react-tinacms-blocks@0.1.0...react-tinacms-blocks@0.1.1-alpha.0) (2019-12-06)

**Note:** Version bump only for package react-tinacms-blocks





# [0.1.0](https://github.com/tinacms/tinacms/compare/react-tinacms-blocks@0.1.0-alpha.1...react-tinacms-blocks@0.1.0) (2019-12-02)

**Note:** Version bump only for package react-tinacms-blocks





# [0.1.0-alpha.1](https://github.com/tinacms/tinacms/compare/react-tinacms-blocks@0.1.0-alpha.0...react-tinacms-blocks@0.1.0-alpha.1) (2019-12-02)


### Features

* **inline-blocks:** add, move, remove blocks ([48b8ef0](https://github.com/tinacms/tinacms/commit/48b8ef0))
* **renderBefore:** lets you create blocks menus ([84fd165](https://github.com/tinacms/tinacms/commit/84fd165))





# 0.1.0-alpha.0 (2019-11-28)


### Features

* **Blocks:** add Block component ([cfcb618](https://github.com/tinacms/tinacms/commit/cfcb618))
